
    // HandleBars.js Starat

    // HandleBars.js End

    //WheelNav.js wheel style set up Start
    var wheel = new wheelnav("divWheel");
	wheel.slicePathFunction = slicePath().DonutSlice;
	wheel.markerPathFunction = markerPath().PieLineMarker;
	wheel.clickModeRotate = false;
	wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
	wheel.markerEnable = true;
	wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
    //WheelNav.js wheel style set up End