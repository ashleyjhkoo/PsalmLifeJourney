window.onload = function () {
    // HandleBars.js Starat

    // HandleBars.js End

    if($(this).width() > 600){
		//WheelNav.js medium large wheel style set up Start
		var wheel = new wheelnav("divWheel");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = false;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
		console.log(wheel);
		//WheelNav.js medium large wheel style set up End
	// } else if($(this).width() <= 640){
			} else{

	    //WheelNav.js small wheel style set up Start
	    var wheel = new wheelnav("divWheelSmall");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = true;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
		wheel.titleFont = ['100 14px Impact, Charcoal, sans-serif'];


		wheelnav.spreaderTitleFont = ['100 14px Impact, Charcoal, sans-serif'];

	    $('text#wheelnav-divWheelSmall-title-1').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-2').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-3').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-0').css("font-size","14px")

	    //WheelNav.js small wheel style set up End

	    }

    $(window).resize(function() {


		if($(this).width() > 640){

	    //WheelNav.js medium large wheel style set up Start
	    var wheel = new wheelnav("divWheel");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = false;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
	    //WheelNav.js medium large wheel style set up End
	    console.log(wheel.getMarkerId());

	    } else {

	    //WheelNav.js small wheel style set up Start
	    var wheel = new wheelnav("divWheelSmall");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = true;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
		wheel.titleFont = ['100 14px Impact, Charcoal, sans-serif'];

	    $('text#wheelnav-divWheelSmall-title-1').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-2').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-3').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-0').css("font-size","14px")
	    //WheelNav.js small wheel style set up End

	    }

    }); 

    $('#wheelnav-divWheelSmall-title-0').css("font-size","14px");
    $('#wheelnav-divWheelSmall-title-1').css("font-size","14px");
    $('#wheelnav-divWheelSmall-title-2').css("font-size","14px");
    $('#wheelnav-divWheelSmall-title-3').css("font-size","14px");

	// MouseClick event => show things
	wheel.navItems[0].navigateFunction = function () { alert('Hello 0'); };
	wheel.navItems[1].navigateFunction = function () { alert('Hello 1'); };
	wheel.navItems[2].navigateFunction = function () { alert('Hello 2'); };
	wheel.navItems[3].navigateFunction = function () { alert('Hello 3'); };
	// wheel.navItems[1].navSlice.mouseclick(function () { alert('Hello navSlice!'); });
	// wheel.navItems[2].navSlice.mouseclick(function () { alert('Hello navSlice!'); });
	// wheel.navItems[3].navSlice.mouseclick(function () { alert('Hello navSlice!'); });
	$('body').click(function() {
		console.log("test");
		var index = wheel.selectedNavItemIndex;
		if (index == 0){
			console.log("Spring");
		} else if (index == 1) {
			console.log("Summer");
		} else if (index == 2) {
			console.log("Winter");
		} else {
			console.log("Fall");
		}
	});


}



	