
    // HandleBars.js Starat

    // HandleBars.js End

    if($(this).width() > 640){
		//WheelNav.js medium large wheel style set up Start
		var wheel = new wheelnav("divWheel");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = false;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
		//WheelNav.js medium large wheel style set up End
	} else {

	    //WheelNav.js small wheel style set up Start
	    var wheel = new wheelnav("divWheelSmall");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = true;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
		wheel.titleFont = ['100 14px Impact, Charcoal, sans-serif'];


		wheelnav.spreaderTitleFont = ['100 14px Impact, Charcoal, sans-serif'];

	    $('text#wheelnav-divWheelSmall-title-1').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-2').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-3').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-0').css("font-size","14px")

	    //WheelNav.js small wheel style set up End

	    }

    $(window).resize(function() {


		if($(this).width() > 640){

	    //WheelNav.js medium large wheel style set up Start
	    var wheel = new wheelnav("divWheel");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = false;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
	    //WheelNav.js medium large wheel style set up End

	    } else {

	    //WheelNav.js small wheel style set up Start
	    var wheel = new wheelnav("divWheelSmall");
		wheel.slicePathFunction = slicePath().DonutSlice;
		wheel.markerPathFunction = markerPath().PieLineMarker;
		wheel.clickModeRotate = true;
		wheel.colors = ['#69a0e8','#d49761','#5562b4','#b479a2'];
		wheel.markerEnable = true;
		wheel.createWheel(['Spring', 'Summer', 'Winter', 'Fall']);
		wheel.titleFont = ['100 14px Impact, Charcoal, sans-serif'];

	    $('text#wheelnav-divWheelSmall-title-1').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-2').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-3').css("font-size","14px")
	    $('text#wheelnav-divWheelSmall-title-0').css("font-size","14px")
	    //WheelNav.js small wheel style set up End

	    }

    });